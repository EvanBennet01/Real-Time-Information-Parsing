#ifndef UPTIME_HPP
#define UPTIME_HPP

void getuptime();
void getidletime();
void getenergy();

#endif 