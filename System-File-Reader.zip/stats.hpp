#ifndef STATS_HPP
#define STATS_HPP

void getCPUActivity();
void getCPUnum();
void getotherstats();

#endif 