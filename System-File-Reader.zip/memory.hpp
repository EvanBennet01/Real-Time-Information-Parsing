#ifndef MEMORY_HPP
#define MEMORY_HPP

void getmemtotal();
void getmemfree();
void getmemcache();
void getmembuff();

#endif 